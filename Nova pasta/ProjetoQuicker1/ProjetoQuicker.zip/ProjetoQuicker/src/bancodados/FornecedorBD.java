/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bancodados;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.classes.Fornecedor;

/**
 *
 * @author Adonias
 */
public class FornecedorBD extends ConexaoBanco
{
    
    
    /**
     * Método responsável por inserir um Novo fornecedor no banco.O método
     * é chamado pela tela de Cadastro de fornecedores
     * BANCO DE DADOS(QUICKER.FORNECEDORES).
     * @param fornecedorRecebido 
     */
    public void inserirFornecedor(Fornecedor fornecedorRecebido)
    {
         try
        {
            conectaBanco(); // Conectando a base de dados
            
            stm = con.createStatement(); // "Criando o botão de execução de comandos SQL"
            
         /*  IDFORNECEDOR,
            RAZAOSOCIALFORNECEDOR,
            NOMEFANTASIAFORNECEDOR, 
            CNPJFORNECEDOR,
            TELEFONEFORNECEDOR,
            CEPFORNECEDOR,
            RUAAVNFORNECEDOR, 
            NUMEROFORNECEDOR,
            BAIRROFORNECEDOR,
            CIDADEFORNECEDOR, 
            ESTADOFORNECEDOR,
            REPRESENTANTEFORNECEDOR, 
            TELEFONEREPRESENTANTE, CELULARREPRESENTANTE, EMAILREPRESENTATNTE*/

            sql = "INSERT INTO QUICKER.FORNECEDORES(RAZAOSOCIALFORNECEDOR, NOMEFANTASIAFORNECEDOR, CNPJFORNECEDOR, TELEFONEFORNECEDOR, CEPFORNECEDOR, RUAAVNFORNECEDOR, NUMEROFORNECEDOR, BAIRROFORNECEDOR, CIDADEFORNECEDOR, ESTADOFORNECEDOR, REPRESENTANTEFORNECEDOR, TELEFONEREPRESENTANTE, CELULARREPRESENTANTE, EMAILREPRESENTATNTE)"+
                    "VALUES ('"+fornecedorRecebido.getRazaoSocialFornecedor()+"',"
                                +"'"+fornecedorRecebido.getNomeFantasiaFornecedor()+"',"
                                +"'"+fornecedorRecebido.getCnpjFornecedor()+"',"
                                +"'"+fornecedorRecebido.getTelefoneFonecedor()+"',"
                                +"'"+fornecedorRecebido.getCepFornecedor()+"',"
                                +"'"+fornecedorRecebido.getRuaAvnFornecedor()+"',"
                                +"'"+fornecedorRecebido.getNumeroFornecedor()+"',"
                                +"'"+fornecedorRecebido.getBairroFornecedor()+"',"
                                +"'"+fornecedorRecebido.getCidadeFornecedor()+"',"
                                +"'"+fornecedorRecebido.getEstadoFornecedor()+"',"
                                +"'"+fornecedorRecebido.getRepresentanteFornecedor()+"',"
                                +"'"+fornecedorRecebido.getTelefoneRepresentante()+"',"
                                +"'"+fornecedorRecebido.getCelularRepresentanteFornecedor()+"',"
                                +"'"+fornecedorRecebido.getEmailRepresentanteFornecedor()+"')";
            
                        System.out.println("SQL DE INSERÇÃO: "+sql);
            
                        stm.executeUpdate(sql); // Executando o SQL escrito acima
            
            
            JOptionPane.showMessageDialog(null, "Fornecedor  cadastrado com sucesso!", "Cadastro Realizado", 1);                     
        }catch(Exception e)
            {
                e.printStackTrace();
            }finally
                    {
                        desconectaBanco();
                    }
      
    }
         /***
    * METODO RESPONSAVEL POR SELECIONAR TODOS OS FORNECEDORES
    * DO BANCO DADOS (QUICKER.FORNECEDORES) E INSERI-LOS EM 
    * UMA LISTA DE FORNECEDORES, QUE SERÁ INSERIDA NO 
    * MODELO DE TABELA (modeloTabelafornecedores).
    * @return 
    */ 
   public ArrayList<Fornecedor> selecionarTodosFornecedores()
    {   
        ArrayList<Fornecedor> listaFornecedores = new ArrayList();
        Fornecedor fornecedor = new Fornecedor();
        try
        {
             conectaBanco();
            
          
            
            stm = con.createStatement();
            
            sql = "SELECT * "
                 +"FROM QUICKER.FORNECEDORES ";
            
            tabelaRetornada = stm.executeQuery(sql);
             while(tabelaRetornada.next()) // Enquanto houverem linhas na tabela para serem lidas
            {
                  fornecedor=new Fornecedor();
                
                  fornecedor.setIdFornecedor(tabelaRetornada.getInt("IDFORNECEDOR"));
                  fornecedor.setRazaoSocialFornecedor(tabelaRetornada.getString("RAZAOSOCIALFORNECEDOR"));
                  fornecedor.setNomeFantasiaFornecedor(tabelaRetornada.getString("NOMEFANTASIAFORNECEDOR"));
                  fornecedor.setCnpjFornecedor(tabelaRetornada.getString("CNPJFORNECEDOR"));
                  fornecedor.setRuaAvnFornecedor(tabelaRetornada.getString("RUAAVNFORNECEDOR"));
                  fornecedor.setNumeroFornecedor(tabelaRetornada.getString("NUMEROFORNECEDOR"));
                  fornecedor.setBairroFornecedor(tabelaRetornada.getString("BAIRROFORNECEDOR"));
                  fornecedor.setCidadeFornecedor(tabelaRetornada.getString("CIDADEFORNECEDOR"));
                  fornecedor.setEstadoFornecedor(tabelaRetornada.getString("ESTADOFORNECEDOR"));
                  fornecedor.setRepresentanteFornecedor(tabelaRetornada.getString("REPRESENTANTEFORNECEDOR"));
                  fornecedor.setTelefoneRepresentante(tabelaRetornada.getString("TELEFONEREPRESENTANTE"));
                  fornecedor.setTelefoneFonecedor(tabelaRetornada.getString("TELEFONEFORNECEDOR"));
                  fornecedor.setCelularRepresentanteFornecedor(tabelaRetornada.getString("CELULARREPRESENTANTE"));
                  fornecedor.setEmailRepresentanteFornecedor(tabelaRetornada.getString("EMAILREPRESENTATNTE"));
                  fornecedor.setCepFornecedor(tabelaRetornada.getString("CEPFORNECEDOR"));
                  
                  listaFornecedores.add(fornecedor);
    
            }
        }catch(Exception e)
           {
               e.printStackTrace();
               System.out.println(e.getMessage());
           }  finally
               {
                 desconectaBanco();
               }
                     return  listaFornecedores  ;
    
    }  
         /***
     * METODO RESPONSAVEL POR 'PEGAR' O FORNECEDOR SELECIONADO E ALTERAR UM OU
     * TODOS OS DADOS QUE SÃO EXIBIDOS NA TELA DE CADASTRO DE FORNECEDORES,
     * E REINSERI-LO NO BANCO DE DADOS (QUICKER.FORNECEDORES) COM AS ALTERAÇÕES
     * REALIZAS.
     * @param idAntigoFornecedor
     * @param fornecedorNovo 
     */
    public void atualizarFornecedor(Fornecedor fornecedorNovo, Fornecedor fornecedorAntigo)
    {
        try
        {
           conectaBanco();
            
            stm = con.createStatement();
            
            sql = "UPDATE QUICKER.FORNECEDORES " +
                  "SET RAZAOSOCIALFORNECEDOR='"+fornecedorNovo.getRazaoSocialFornecedor()+"' "
                   +", NOMEFANTASIAFORNECEDOR='"+fornecedorNovo.getNomeFantasiaFornecedor()+"' "
                   +",CNPJFORNECEDOR='"+fornecedorNovo.getCnpjFornecedor()+"' "
                   +", TELEFONEFORNECEDOR='"+fornecedorNovo.getTelefoneFonecedor()+"'"
                   +", CEPFORNECEDOR='"+fornecedorNovo.getCepFornecedor()+"' "
                   +",RUAAVNFORNECEDOR='"+fornecedorNovo.getRuaAvnFornecedor()+"' "
                   +", NUMEROFORNECEDOR='"+fornecedorNovo.getNumeroFornecedor()+"'"
                   +", BAIRROFORNECEDOR='"+fornecedorNovo.getBairroFornecedor()+"' "
                   +",CIDADEFORNECEDOR='"+fornecedorNovo.getCidadeFornecedor()+"' "
                   +", ESTADOFORNECEDOR='"+fornecedorNovo.getEstadoFornecedor()+"' "
                   +", REPRESENTANTEFORNECEDOR='"+fornecedorNovo.getRepresentanteFornecedor()+"' "
                   +", TELEFONEREPRESENTANTE='"+fornecedorNovo.getTelefoneRepresentante()+"' "
                   +", CELULARREPRESENTANTE='"+fornecedorNovo.getCelularRepresentanteFornecedor()+"' "
                   +", EMAILREPRESENTATNTE='"+fornecedorNovo.getEmailRepresentanteFornecedor()+"'"
                   +"WHERE IDFORNECEDOR = "+fornecedorAntigo.getIdFornecedor();
                   
                   System.out.println(sql);
            
                   stm.executeUpdate(sql);
            
            JOptionPane.showMessageDialog(null, "Fornecedor alterado com sucesso!", "Aviso", 3);                     
            
        } catch(Exception e)
            {
               e.printStackTrace();
            }finally
                {
                     desconectaBanco();
                }   
    }  
        /***
     * METODO RESPONSAVEL POR REMOVER O FORNECEDOR SELECINADO DA LISTA
     * DE FORNECEDORES EXIBIDA NA TABELA E DO BANCO DE DADOS (QUICKER.FORNECEDORES).
     * @param idFornecedor
     * @param  
     */
   
    public void deletarFornecedor(int idFornecedor, String toString) {
        
         try
        {
           conectaBanco();
            
            stm = con.createStatement();
            
            sql = "DELETE FROM QUICKER.FORNECEDORES WHERE IDFORNECEDOR="+idFornecedor;
            System.out.println(sql);
            System.out.println("ID do FORNECEDOR = "+idFornecedor);
             stm.executeUpdate(sql);
            
            
           // JOptionPane.showMessageDialog(null, "Funionario "+NomeFuncionario+" foi deletado com sucesso!", "Aviso", 3); 
            JOptionPane.showMessageDialog(null, "Fornecedor foi deletado com sucesso!", "Aviso", 3); 
            
            
        }catch(Exception e)
            {
               e.printStackTrace();
            }finally
                {
                     desconectaBanco();
                }
    }
        
        
}
      
