/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo.tabelas;

import java.util.ArrayList;
import modelo.classes.Cliente;

/**
 *
 * @author Adonias
 */
public class ModeloTabelaClientes extends javax.swing.table.AbstractTableModel 
{
    ArrayList<Cliente> listaCliente = new ArrayList();
    
    Cliente cliente;
    
        public int getRowCount() {
        return listaCliente.size();
    } 
          public int getColumnCount() {
        return 4;
    }
     public String getColumnName(int columnIndex)
    {
        switch(columnIndex)
        {
            case 0: return "Nome";
            case 1: return "CPF";
            case 2: return "Endereço";
            case 3: return "Contatos";
          
        }
        return null;
    }
      public Object getValueAt(int rowIndex, int columnIndex) {
        cliente = listaCliente.get(rowIndex);
        
        switch(columnIndex)
        {
            
            case 0: return cliente.getNomeCliente();
            case 1:return cliente.getCpfCliente();
            case 2: return cliente.getRuaAvnCliente()+" | "+cliente.getNumeroCliente()+" | "+cliente.getBairroCliente();
            case 3: return cliente.getTelefoneCliente()+" | "+cliente.getCelularCliente();
            
        }
        return null;
    }
      /***
         * MÉTODOS PARA ALIMENTAÇÃO DA LISTA DE CLIENTES.
         * @param listaClientes
         */
        public void inserirlistaClientes(ArrayList<Cliente> listaClientes)
    {
        this.listaCliente = listaClientes;
    }
    
    public ArrayList<Cliente> retornalistaClientes()
    {
        return this.listaCliente;
    }
}
